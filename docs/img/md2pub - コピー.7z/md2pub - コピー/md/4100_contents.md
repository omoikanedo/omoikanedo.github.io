---
template: template/400_contents.ejs
css: css/400_contents.css
---

::: header #2
# ソフトウェアの構成
──
:::

## 2.1. ディレクトリ構成
## 2.2. コンテンツ構成


