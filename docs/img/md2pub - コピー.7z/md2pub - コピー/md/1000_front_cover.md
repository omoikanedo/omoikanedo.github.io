---
template: template/100_front_cover.ejs
---

# Markdown＋CSS組版 md2pub

## 利用マニュアル

<div class="ver">Ver.1.0</div>
<div class="rev">Rev.2021070301</div>

<div class="right">
  <table>
    <tr>
      <th>承認</th><th>査閲</th><th>作成</th>
    </tr>
    <tr>
      <td></td><td></td><td></td>
    </tr>
  </table>
</div>

