---
template: template/700_colophon.ejs
css: css/700_colophon.css
---

# 奥付タイトル

----

|---------------|-----------|
|2020年4月1日   |初版発行   |
|2021年4月1日   |2版発行    |
|発行           |(発行者名) |
|連絡先         |(連絡先)   |

----

(c) copyright


