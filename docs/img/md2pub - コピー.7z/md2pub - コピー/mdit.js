const footnote = require('markdown-it-footnote');
const deflist = require('markdown-it-deflist');
const container = require('markdown-it-container');
const meta = require('markdown-it-meta')
const ruby = require('markdown-it-ruby')
const sup = require('markdown-it-sup')
const sub = require('markdown-it-sub')
const table = require('markdown-it-multimd-table')
const md = require('markdown-it')({
    html: true,
})
.use(footnote)
.use(deflist)
.use(meta)
.use(ruby)
.use(sup)
.use(sub)
.use((table), {
  multiline:  true,
  rowspan:    true,
  headerless: true,
})
.use((container), 'header', {
  validate: function(params) {
    return params.trim().match(/^header\s+(.*)$/);
  },
  render: function (tokens, idx) {
    var m = tokens[idx].info.trim().match(/^header\s+(.*)$/);

    if (tokens[idx].nesting === 1) {
      // opening tag
      return '<div class="header">\n<div class="sectionno">\n' + md.utils.escapeHtml(m[1]) + '\n</div>\n<div class="title">\n';

    } else {
      // closing tag
      return '  </div>\n</div>\n';
    }
  }
})
.use((container), 'refbox', {
  validate: function(params) {
    return params.trim().match(/^refbox$/);
  },
  render: function (tokens, idx) {
    if (tokens[idx].nesting === 1) {
      // opening tag
      return '<div class="refbox">\n';
    } else {
      // closing tag
      return '</div>\n';
    }
  }
})
.use((container), 'footnote', {
  validate: function(params) {
    return params.trim().match(/^footnote$/);
  },
  render: function (tokens, idx) {
    if (tokens[idx].nesting === 1) {
      // opening tag
      return '<div class="footnote">\n';
    } else {
      // closing tag
      return '</div>\n';
    }
  }
})
.use((container), 'boxframe', {
  validate: function(params) {
    return params.trim().match(/^boxframe$/);
  },
  render: function (tokens, idx) {
    if (tokens[idx].nesting === 1) {
      // opening tag
      return '<div class="boxframe">\n';
    } else {
      // closing tag
      return '</div>\n';
    }
  }
})
.use((container), 'notebox', {
  validate: function(params) {
    return params.trim().match(/^notebox\s+(.*)$/);
  },
  render: function (tokens, idx) {
    var m = tokens[idx].info.trim().match(/^notebox\s+(.*)$/);
    if (tokens[idx].nesting === 1) {
      // opening tag
      return '<div class="notebox" title="' + md.utils.escapeHtml(m[1]) + '">\n';
    } else {
      // closing tag
      return '</div>\n';
    }
  }
});
module.exports = md