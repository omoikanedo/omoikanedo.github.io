// file I/O setting
const { promisify } = require('util');
const path = require('path');
const fs = require('fs');
const fse = require('fs-extra');
const readFile = promisify(fs.readFile);
const writeFile = promisify(fs.writeFile);
const ejs = require('ejs');

// markdown-it setting
const md = require('./mdit.js')

// arg setting
const args = process.argv.slice(2);
const mdDir = path.resolve(__dirname, args[0]);
const htmlDir = path.resolve(__dirname, args[1]);

/**
 * Converting Markdown files to HTML files.
 * @param {string} input target markdown file path.
 * @param {string} output target html file path.
 */
const convertMdToHtml = async (input, output) => {
    try {
        const markdown = await readFile(input, 'utf-8');
        const body = md.render(markdown);
        const meta = md.meta;
        console.log(` template   : ${meta.template}`);
        console.log(` meta_title : ${meta.title}`);
        console.log(` meta_css : ${meta.css}`);
        const template = fs.readFileSync(meta.template,'utf8');
        const html = ejs.render(template,{
            title: meta.title,
            css: meta.css,
            body: body,
        });
        await writeFile(output, html);
    } catch (e) {
        console.error(`error: ${e}`);
    }
}

/**
 * Determines if the target file path is a file.
 * @param {string} filepath target file path.
 * @return {boolean} True for files, False otherwise.
 */
const isFile = function(filepath) {  
    return fs.existsSync(filepath) && fs.statSync(filepath).isFile();
};

/**
 * copySync fillter function.
 * @param {string} src target souce path.
 * @param {string} dist target dist path.
 */
const convertFilter = (src, dist) => {
    if (isFile(path.resolve(src)) && path.extname(src) == '.md') {
        const baseName = path.basename(src);
        const distFileName = baseName.replace(/\.md$/g, '.html');
        const distFilePath = path.dirname(dist);
        const mdFilePath = path.resolve(src);
        const htmlFilePath = path.resolve(distFilePath + '/' + distFileName);
        convertMdToHtml(mdFilePath, htmlFilePath);
        console.log(`conversion: ${mdFilePath} -> ${htmlFilePath}`);
        return false
    }else{
        return true
    }
}

/**
 * entry-point function.
 * @param {string} mdDir target markdown dir path.
 * @param {string} htmlDir target html dir path.
 */
const md2html = (mdDir, htmlDir) => {
    console.log(`===== md2html2 =====`);
    console.log(`Markdown Dir: ${mdDir}`);
    console.log(`HTML Dir: ${htmlDir}`);
    fse.copySync(path.resolve(mdDir), path.resolve(htmlDir), { filter: convertFilter })
}

md2html(mdDir, htmlDir)